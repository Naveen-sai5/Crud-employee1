import { useState } from "react";

function Form(props) {

    const [employee, setEmployee] = useState(props.data);
    const [sumitted, setSubmitted] = useState(false)

    let changeFormData = (event) => {
        const { name, value } = event.target;
        setEmployee({ ...employee, [name]: value })
    }
    return (
        <div className="form-overlay">
            <form>
                <div className="form-group">
                    <label>Name:</label>
                    <input className="form-control mt-2" value={employee.name} type="text" name="name" placeholder="Enter Name"
                        onChange={changeFormData} />
                    {
                        sumitted && employee.name.length < 5 && <span className="text-danger">Employee name must be 5 charecters</span>
                    }

                </div>
                <div className="form-group">
                    <label>Salary:</label>
                    <input className="form-control mt-2"

                        value={employee.salary}
                        onChange={changeFormData}

                        type="number" name="salary" placeholder="Enter Salary" />
                    {
                        sumitted && employee.salary === "" && <span className="text-danger">Employee Salary required</span>
                    }
                </div>
                <div className="form-group">
                    <label>Designation:</label>
                    <select className="form-control mt-2" name="designation"

                        value={employee.designation}

                        onChange={changeFormData}

                    >

                        <option value='-1'></option>
                        <option value={'PAT'}>pat</option>
                        <option value={'PA'}>pa</option>
                        <option value={'A'}>a</option>

                    </select>

                    {
                        sumitted && employee.designation === "" && <span className="text-danger">Employee designation required</span>
                    }

                </div>

                <button className="btn btn-primary float-end"

                    onClick={(e) => {
                        setSubmitted(true)
                        e.preventDefault();
                        if (!!employee.name && !!employee.salary && !!employee.designation) {
                            props.add(employee)
                        }



                    }}

                >Send</button>
                <button className="btn btn-danger float-end"
                    onClick={(e) => {
                        e.preventDefault();
                        props.close()


                    }}
                >Cancel</button>

            </form>

        </div>
    )
}


export default Form